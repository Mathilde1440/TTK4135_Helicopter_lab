/*
 * helicopter_R2016b_dt.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "helicopter_R2016b".
 *
 * Model version              : 11.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Tue Feb 24 14:28:43 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(t_card),
  sizeof(t_task)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "t_card",
  "t_task"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&helicopter_R2016b_B.FromWorkspace2), 0, 0, 32 }
  ,

  { (char_T *)(&helicopter_R2016b_DW.HILInitialize_AIMinimums[0]), 0, 0, 70 },

  { (char_T *)(&helicopter_R2016b_DW.HILInitialize_Card), 14, 0, 1 },

  { (char_T *)(&helicopter_R2016b_DW.HILReadEncoderTimebase_Task), 15, 0, 1 },

  { (char_T *)(&helicopter_R2016b_DW.FromWorkspace2_PWORK.TimePtr), 11, 0, 25 },

  { (char_T *)(&helicopter_R2016b_DW.HILInitialize_ClockModes[0]), 6, 0, 46 },

  { (char_T *)(&helicopter_R2016b_DW.HILInitialize_POSortedChans[0]), 7, 0, 8 },

  { (char_T *)(&helicopter_R2016b_DW.FromWorkspace2_IWORK.PrevIndex), 10, 0, 2 },

  { (char_T *)(&helicopter_R2016b_DW.If_ActiveSubsystem), 2, 0, 2 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  9U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&helicopter_R2016b_P.K[0]), 0, 0, 13 },

  { (char_T *)(&helicopter_R2016b_P.HILWriteAnalog_channels[0]), 7, 0, 2 },

  { (char_T *)(&helicopter_R2016b_P.HILInitialize_OOTerminate), 0, 0, 50 },

  { (char_T *)(&helicopter_R2016b_P.HILInitialize_CKChannels[0]), 6, 0, 10 },

  { (char_T *)(&helicopter_R2016b_P.HILInitialize_AIChannels[0]), 7, 0, 37 },

  { (char_T *)(&helicopter_R2016b_P.HILInitialize_Active), 8, 0, 37 },

  { (char_T *)(&helicopter_R2016b_P.HILReadEncoderTimebase_Overflow), 3, 0, 1 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  7U,
  rtPTransitions
};

/* [EOF] helicopter_R2016b_dt.h */
